ALTER TABLE `#__session` MODIFY `client_id` tinyint unsigned DEFAULT NULL;
