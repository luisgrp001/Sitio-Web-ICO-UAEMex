ALTER TABLE [#__redirect_links] ALTER COLUMN [new_url] [nvarchar](2048);
